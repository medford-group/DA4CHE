Model Validation — Problem Set
==============================

This problem set is worth 100 points:

  Part A - Skill Checks   (30 pts)  auto-graded, unlimited attempts
  Part B - Visualization  (35 pts)  peer graded
  Part C - Open Ended     (35 pts)  peer graded

The parts build on each other. Part A works out the syntax you need for Part B, and
Part B produces the evidence you argue from in Part C. Do them in order.

Contents
--------
  Topic2.2-Model_Validation_Problems.ipynb
  data/henry_law.csv

Running it
----------
Open the notebook from *this* folder, so that the `data/...` paths resolve. The cells
marked `# YOUR CODE HERE` are yours to complete; everything else is provided.

Part A has a `check(...)` helper defined in the setup cell — run that cell first, then run
the check after each answer. It compares a digest of your answer, so the expected numbers
are not sitting in the notebook. Nothing is recorded: this copy is practice. The graded
version lives on Vocareum, where you may resubmit as often as you like.

Accompanies: 2-regression/Topic2.2-Model_Validation.md
Dataset source: 10.5194/acp-23-10901-2023

Solutions are not included.
