Python Basics — Problem Set
===========================

This problem set is worth 100 points:

  Part A - Skill Checks   (30 pts)  auto-graded, unlimited attempts
  Part B - Visualization  (35 pts)  peer graded
  Part C - Open Ended     (35 pts)  peer graded

The parts build on each other. Part A works out the syntax you need for Part B, and
Part B produces the evidence you argue from in Part C. Do them in order.

Contents
--------
  Topic1.1-Python_Basics_Problems.ipynb
  data/water_properties.csv

Running it
----------
Open the notebook from *this* folder, so that the `data/...` paths resolve. The cells
marked `# YOUR CODE HERE` are yours to complete; everything else is provided.

Part A is checked by otter-grader. On Vocareum the grader is already configured and you
may resubmit as often as you like. Running `grader.check(...)` outside Vocareum requires
`pip install otter-grader` and the test files, which are distributed with the assignment.

Accompanies: 1-numerical_methods/Topic1.1-Python_Basics.md
Dataset source: https://webbook.nist.gov/chemistry/fluid/

Solutions are not included.
