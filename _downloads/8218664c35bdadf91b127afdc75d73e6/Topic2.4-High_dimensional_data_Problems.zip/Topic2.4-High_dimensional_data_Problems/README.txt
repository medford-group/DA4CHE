High-dimensional Data — Problem Set
===================================

This problem set is worth 100 points:

  Part A - Skill Checks   (30 pts)  short answers, each with a self-check
  Part B - Visualization  (35 pts)  plots plus written interpretation
  Part C - Open Ended     (35 pts)  one synthesis problem

The parts build on each other. Part A works out the syntax you need for Part B, and
Part B produces the evidence you argue from in Part C. Do them in order.

Contents
--------
  Topic2.4-High_dimensional_data_Problems.ipynb
  data/solvent_ir_batchA.csv

Running it
----------
Open the notebook from *this* folder, so that the `data/...` paths resolve. The cells
marked `# YOUR CODE HERE` are yours to complete; everything else is provided.

Part A has a `check(...)` helper defined in the setup cell — run that cell first, then run
the check after each answer. It compares a digest of your answer, so the expected numbers
are not sitting in the notebook. Nothing is recorded, and you may run it as often as
you like.

Accompanies: 2-regression/Topic2.4-High_dimensional_data.md
Dataset source: https://webbook.nist.gov/chemistry/

Solutions are not included.
